<?php

 
$con = $con = mysql_connect("localhost","nusrhjdq_kits_user","2%P8R}WgZN%}");
if (!$con)
  {
 
  die('Could not connect: ' . mysql_error());
  }
mysql_select_db("nusrhjdq_kits_db", $con);


$Type=$_GET['Type'];

if($Type==0){
 
$result = mysql_query("SELECT * FROM Book");
while($row = mysql_fetch_assoc($result))
  {
	$output[]=$row;
  }
print(json_encode($output));   
}else{
    
$result = mysql_query("SELECT * FROM Book
ORDER BY DownloadCount DESC;");
while($row = mysql_fetch_assoc($result))
  {
	$output[]=$row;
  }
print(json_encode($output));
}
mysql_close($con);
?>