<?php
$servername = "localhost";
$username = "nusrhjdq_kits_user";
$password = "2%P8R}WgZN%}";
$dbname = "nusrhjdq_kits_db";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$data = json_decode(file_get_contents('php://input'), true); 				

$Title=$data['Title'];
$Description = $data['Description'];
$CoverImage = $data['CoverImage'];
$PdfUrl=$data['PdfUrl'];
$Category = $data['Category'];
$Comment = $data['Comment'];
$CreatedAt = $data['CreatedAt']; 

$sql = "INSERT INTO Book (Title,Description,CoverImage,PdfUrl,Category,Comment,CreatedAt)
VALUES ('{$Title}','{$Description}','{$CoverImage}','{$PdfUrl}','{$Category}','{$Comment}','{$CreatedAt}' )";
if ($conn->query($sql) === TRUE) {
    $data = [ 'msg' => 'Your pdf Is Live !' ];
    
    echo $data;

} else {
    
    $data = [ 'msg' => 'Something Went Wrong !' ];
    
    echo $data;
    
     
}
$conn->close();
?> 