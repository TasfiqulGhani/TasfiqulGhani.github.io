<?php

 
$con = $con = mysql_connect("localhost","nusrhjdq_kits_user","2%P8R}WgZN%}");
if (!$con)
  {
 
  die('Could not connect: ' . mysql_error());
  }
mysql_select_db("nusrhjdq_kits_db", $con);


$Id=$_GET['Id'];

$sql = "UPDATE Book
SET DownloadCount = DownloadCount+1
WHERE Id = '$Id';";
if ($con->query($sql) === TRUE) {
    $data = [ 'msg' => 'Your pdf Is Live !' ];
    
    echo $data;

} else {
    
    $data = [ 'msg' => 'Something Went Wrong !' ];
    
    echo $data;
    
     
}
mysql_close($con);
?>