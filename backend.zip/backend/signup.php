<?php

$servername = "localhost";
$username = "nusrhjdq_test_user";
$password = "%4kY,@~pRLkA";
$dbname = "nusrhjdq_test2";


//Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
 
$Name=$_GET['Name'];
$Email = $_GET['Email'];
$Phone = $_GET['Phone'];
$Address=$_GET['Address'];
$Website = $_GET['Website'];
$Type = $_GET['Type'];
$Password = $_GET['Password'];

$sql = "INSERT INTO User (Name,Email,Phone,Address,Website,Type,Password)

VALUES ('{$Name}','{$Email}','{$Phone}','{$Address}','{$Website}','{$Type}','{$Password}')";

if ($conn->query($sql) === TRUE) {
    echo "Registration Confirmed !";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
$conn->close();
?> 