<?php
$servername = "localhost";
$username = "nusrhjdq_test_user";
$password = "%4kY,@~pRLkA";
$dbname = "nusrhjdq_test2";

$con = new mysqli($servername, $username, $password, $dbname);
if (!$con)
  {
  die('Could not connect: ' . mysql_error());
  } 
$result = mysqli_query($con,"SELECT * FROM User");
while($row = mysqli_fetch_assoc($result))
  {
	$output[]=$row;
  }
print(json_encode($output));
mysqli_close($con);
?>