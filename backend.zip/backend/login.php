<?php

$servername = "localhost";
$username = "nusrhjdq_test_user";
$password = "%4kY,@~pRLkA";
$dbname = "nusrhjdq_test2";


//Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
  
$Email = $_GET['Email']; 
$Password = $_GET['Password'];

$sql = "SELECT * FROM User where Email='$Email' and Password='$Password'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    
     while($row = $result->fetch_assoc()) { 
   print(json_encode($row));
    
    
  }

    
} else {
    echo "Invalid Credentials !";
}
$conn->close();
?>