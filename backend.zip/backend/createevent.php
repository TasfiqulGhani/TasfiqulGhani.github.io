<?php

$servername = "localhost";
$username = "nusrhjdq_test_user";
$password = "%4kY,@~pRLkA";
$dbname = "nusrhjdq_test2";


//Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
 
  


$Name=$_GET['Name'];
$Address = $_GET['Address'];
$Date = $_GET['Date'];
$Start=$_GET['Start'];
$End = $_GET['End'];
$TotalVol = $_GET['TotalVol'];  
$CreatorId = $_GET['CreatorId'];  

$sql = "INSERT INTO Event (Name,Address,Date,Start,End,TotalVol,CreatorId)

VALUES ('{$Name}','{$Address}','{$Date}','{$Start}','{$End}','{$TotalVol}','{$CreatorId}')";

if ($conn->query($sql) === TRUE) {
    echo "Event Created !";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
$conn->close();
?> 