<?php

$servername = "localhost";
$username = "nusrhjdq_test_user";
$password = "%4kY,@~pRLkA";
$dbname = "nusrhjdq_test2";


//Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
 
$result = $conn->query("SELECT * FROM Event");

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
    $output[]=$row;
  }
print(json_encode($output));
} else {
    echo "0 results";
} 
$conn->close();
?> 