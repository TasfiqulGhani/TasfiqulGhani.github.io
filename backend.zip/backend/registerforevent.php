<?php

$servername = "localhost";
$username = "nusrhjdq_test_user";
$password = "%4kY,@~pRLkA";
$dbname = "nusrhjdq_test2";


//Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
  

$UserId=$_GET['UserId'];
$EventId = $_GET['EventId'];
$Date = $_GET['Date'];
$Status=$_GET['Status']; 

$sql = "INSERT INTO Registrations (UserId,EventId,Date,Status)

VALUES ('{$UserId}','{$EventId}','{$Date}','{$Status}')";

if ($conn->query($sql) === TRUE) {
    echo "Successful !";
} else {
    echo "Something went wrong !" . $conn->error;
}
$conn->close();
?> 